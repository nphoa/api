<?php

namespace App\Http\Controllers;
use Hash;
use Illuminate\Http\Request;
use JWTAuth;
use JWTAuthException;
use App\User;
use DB;
class UserController extends Controller
{
	public function register(Request $req)
	{
		$user = User::create([
			'name' => $req->get('name'),
			'email' => $req->get('email'),
			'password' => Hash::make($req->get('password'))
		]);
		$user->save();
		return response()->json([
			'status'=> 200,
			'message'=> 'User created successfully',
			'data'=>$user
		]);
	}
	public function updateUser(Request $req)
	{
		$user = User::where('email',$req->get('email')) -> first();
		if($user){
			$user->name = $req->get('name');
			$user->email = $req->get('email');
			$user->password = Hash::make($req->get('password'));
			$user->save();
		}
		return response()->json([
			'status'=> 200,
			'message'=> 'User updated successfully',
			'data'=>$user
		]);
	}
	public function login(Request $request)
	{
		$credentials = $request->only('email', 'password');

		$jwt = '';

		try {
			$jwt = JWTAuth::attempt($credentials);
			JWTAuth::setToken($jwt);
		} catch (JWTAuthException $e) {
			return response()->json([
				'response' => 'error',
				'message' => 'failed_to_create_token',
			], 500);
		}
		return response()->json([
			'response' => 'success',
			'result' => ['token' => $jwt,'user'=>JWTAuth::user()]
		]);

	}

	public function refresh()
	{
		$token = JWTAuth::getToken();
		
		try{
			$token = JWTAuth::refresh($token);
			return response()->json(['token'=>$token]);
		}catch(TokenExpiredException $e){

		}	
	}
	public function getUserInfo()
	{
		$user = JWTAuth::user();
		dd($user->name);
	}
}
