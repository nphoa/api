<?php

namespace App\Http\Controllers;
use App\Article;
use Illuminate\Http\Request;
use App\Comment;
use DB;

class ArticleController extends Controller
{
    public function index()
    {
        return Article::all();
    }

    public function show($id)
    {
        return Article::find($id);
    }

    public function store(Request $request)
    {
        return Article::create($request->all());
    }

    public function update(Request $request, $id)
    {
        $article = Article::findOrFail($id);
        $article->update($request->all());

        return $article;
    }

    public function delete(Request $request, $id)
    {
        $article = Article::findOrFail($id);
        $article->delete();

        return 204;
    }
    public function commentArticle(Request $request)
    {
        $data =  $request->json()->all();
        //return $data["Object"];
        DB::table('comments')->insert(
            ['Object' => $data["Object"], 'objectID' => $data["objectID"],'body'=>$data["body"],'createdBy'=>1]
        );
        return response()
        ->json(['status' => 'success']);
    }

    public function getAllComment()
    {
         return Comment::all();
    }

    public function getCommentById(Request $req)
    {
       $idArticle =  $req->get('idArticle');
       $data =  DB::table('comments')->where('objectID',$idArticle)->get();
       return response()
        ->json(['data' => $data]);
    }
}
